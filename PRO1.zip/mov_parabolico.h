#ifndef mov_parbolico_H
#define mov_parbolico_H

#include <iostream>
#include <math.h>

using namespace std;

const float PI= 3.1416;       //rad
const float g = 9.8;          //m/s^2

void mov_parabolico_friccion();

#endif // PARABOLIC_MOTION_H
