#ifndef colision_H
#define colision_H

void Colision();

#endif 
