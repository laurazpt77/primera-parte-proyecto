#include "mov_parabolico.cpp"
#include "colision.cpp"



int main()
{
 
   mov_parabolico_friccion();
   Colision();



    return 0;

}
