#include "mov_parabolico.h"

void mov_parabolico_friccion()
{

  // Variables para movimiento sin fuerza friccion

  float v0=0;                          // velocidad inicial de disparo
  float y0=0;                          // altura (posicion) inicial en y
  float theta=0;                       // angulo de disparo
  float t=0;                           // tiempo de duracion de movimiento
  float vy,vx;                         // velocidad en componente "y" y componente en "x"
  float x,y;                           // posicion (altura y distancia) en "x" y en "y"

  // Variables para movimiento con fuerza de friccion

  float k=0;                           // constante de friccion
  float m=0;                           // masa
  float alpha=0;                       // angulo
  float rad=0;                         // radio
  float vm=0;                          // magnitud del vector velocidad
  float vxf, vyf;                      // velocidad final en "x" y "y"
  float ax, ay;                        // aceleracion en "x" y "y"
  float xf, yf;                        // posicion final en "x" y "y"

  cout << "ingrese velocidad inicial" << endl;
  cin >> v0;
  cout << "ingrese posicion inicial en y" << endl;
  cin >> y0;
  cout << "ingrese angulo" << endl;
  cin >> theta;
  cout << "ingrese tiempo" << endl;
  cin >> t;
  cout << "ingrese friccion" << endl;
  cin >> k;

  float mp=t;                      // variable auxiliar
  t=0;

  if (k == 0){


      cout << "\t\t\t MOVIMIENTO PARABOLICO SIN FRICCION" << endl;

      for(int i=0;i<=mp;i++)
       {

        x= v0*cos((theta*PI)/180)*t;                       // ecuacion para posicion en x
        y= y0+v0*sin((theta*PI)/180)*t-0.5*g*pow(t,2);     // ecuaciones para posicion en y
        vx= v0*cos((theta*PI)/180);                        // ecuacion para componente de velocidad en x
        vy= v0*sin((theta*PI)/180)-g*t;                    // ecuacion para componente de velocidad en y con aceleracion constante

        cout << "\nposicion en x para t= "<<t << " seg. es: "<<x<< " m " << endl;
        cout << "posicion en y para t= "<<t<<" seg. es: "<<y<< " m " <<  endl;
        cout << "velocidad en x par t= "<<t<<" seg. es: "<<vx<< " m/s " <<  endl;
        cout << "velocidad en y para t= "<<t<<" seg. es: "<<vy<< " m/s " << endl;
        cout <<endl;

        t++;

       }
   }
    else {

         cout << "ingrese masa" << endl;
         cin >> m;
         cout << "ingrese radio" << endl;
         cin >> rad;

         cout << "\t\t\tMOVIMIENTO PARABOLICO CON FRICCION" << endl;

          for(int i=0;i<=mp;i++)
          {
              // estas dos ecuaciones se toman del movimieno parablico sin friccion, para hallar el angulo (alpha) de la friccion

              vx= v0*cos((theta*PI)/180);
              vy= v0*sin((theta*PI)/180)-g*t;
              alpha= atan(vx/vy);


              // las siguientes ecuaciones describen el movimiento con friccion

              vm=sqrt(pow(vx,2)+pow(vy,2));                            // magnitud velocidad
              ax= -((k*pow(vm,2)*pow(rad,2))/m)*cos(alpha*PI/180);     // ecuacion para la aceleracion en x
              ay= -((k*pow(vm,2)*pow(rad,2))/m)*sin(alpha*PI/180)-g;   // ecuacion para la aceleracion en y

              vxf= v0*cos(theta*PI/180)+(ax*t);                       // ecuacion para componente de velocidad en x
              vyf= v0*sin(theta*PI/180)+(ay*t);                       // ecuacion para componente de velocidad en y

              xf= v0*cos(theta*PI/180)*t+(1/2)*ax*pow(t,2);           // ecuacion para posicion en x
              yf= y0+v0*sin(theta*PI/180)*t+(1/2)*ay*pow(t,2);        // ecuaciones para posicion en y



              cout<<"\nposicion en x para t= "<<t<<" seg. es: "<<xf<< " m " <<endl;
              cout<<"posicion en y para t= "<<t<<" seg. es: "<<yf<< " m " <<endl;
              cout<<"Aceleracion en x para t= "<<t<<" seg. es: "<<ax<< " m/s^2 " <<endl;
              cout<< "Aceleracion en y para t= "<<t<<" seg. es: "<<ay<< " m/s^2 " <<endl;
              cout<< "velocidad en x para t= "<<t<<" seg. es: "<<vxf<< " m/s " <<endl;
              cout<< "velocidad en y para t= "<<t<<" seg. es: "<<vyf<< " m/s " <<endl;
              cout <<endl;
              t++;
          }

   }


}
